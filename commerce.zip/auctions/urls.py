from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),  # Active listings are shown in the index view
    path("login", views.login_view, name="login"),  # User login
    path("logout", views.logout_view, name="logout"),  # User logout
    path("register", views.register, name="register"),  # User registration
    path("create", views.create_listing, name="create_listing"),  # Create a new listing
    path("listing/<int:listing_id>", views.view_listing, name="view_listing"),  # View a specific listing
    path("listing/<int:listing_id>/add_to_watchlist", views.add_to_watchlist, name="add_to_watchlist"),  # Add/remove listing from watchlist
    path("listing/<int:listing_id>/place_bid", views.place_bid, name="place_bid"),  # Place a bid on a listing
    path("listing/<int:listing_id>/add_comment", views.add_comment, name="add_comment"),  # Add a comment to a listing
    path("watchlist", views.view_watchlist, name="view_watchlist"),  # View user's watchlist
    path("categories", views.view_categories, name="categories"),  # View all categories
    path("category/<int:category_id>", views.view_category_listings, name="view_category_listings"),  # View listings in a specific category
    path("listing/<int:listing_id>/close_auction", views.close_auction, name="close_auction"),  # Close an auction
]
 
