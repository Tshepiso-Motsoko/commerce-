# Standard imports for Django views and authentication
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import IntegrityError
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
import logging

# Set up logging
logger = logging.getLogger(__name__)

# Import models and forms from the current directory
from .models import User, Listing, Bid, Comment, Watchlist, Category
from .forms import CreateListingForm, BidForm, CommentForm

# View for the main page of the site that shows all active listings
def index(request):
    active_listings = Listing.objects.filter(active=True).order_by('-created_at')
    return render(request, "auctions/index.html", {"active_listings": active_listings})

# View for user login
def login_view(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect("index")
        else:
            messages.error(request, "Invalid username and/or password.")
    return render(request, "auctions/login.html")

# View for user logout
def logout_view(request):
    logout(request)
    return redirect("index")

# View for new user registration
def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            messages.error(request, "Passwords must match.")
            return render(request, "auctions/register.html")
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
            login(request, user)
            return redirect("index")
        except IntegrityError:
            messages.error(request, "Username already taken.")
            return render(request, "auctions/register.html")
    return render(request, "auctions/register.html")

# View for creating a new auction listing
@login_required
def create_listing(request):
    if request.method == "POST":
        form = CreateListingForm(request.POST, request.FILES)
        if form.is_valid():
            listing = form.save(commit=False)
            listing.creator = request.user
            listing.save()
            messages.success(request, "Listing created successfully!")
            return redirect("index")
        else:
            messages.error(request, "Error creating listing. Please check your form.")
    else:
        form = CreateListingForm()
    return render(request, "auctions/create_listing.html", {"form": form})

# View for displaying all listing categories
def view_categories(request):
    categories = Category.objects.all()  # Ensure Category is imported at the top
    return render(request, "auctions/categories.html", {"categories": categories})

# View for displaying the details of a specific listing
def view_listing(request, listing_id):
    listing = get_object_or_404(Listing, pk=listing_id)
    comments = listing.comments.all()
    is_in_watchlist = False
    if request.user.is_authenticated:
        is_in_watchlist = listing.watchlisted_by.filter(pk=request.user.pk).exists()

    # Initialize the variables
    user_is_winner = False
    winner_username = None

    # Check if the auction is closed and if the current user is the winner
    if not listing.active:
        winner_username = listing.winner.username if listing.winner else 'No winner'
        if listing.winner == request.user:
            user_is_winner = True

        # Log the current user and the winner of the listing for debugging
        logger.debug(f"Current user: {request.user.username if request.user.is_authenticated else 'Anonymous'}, Listing winner: {winner_username}")

    # Render the page with context
    return render(request, "auctions/view_listing.html", {
        "listing": listing,
        "comments": comments,
        "is_in_watchlist": is_in_watchlist,
        "user_is_winner": user_is_winner,
        "winner_username": winner_username,
        "bid_form": BidForm(),
        "comment_form": CommentForm(),
    })

# View for adding or removing a listing from the user's watchlist
@login_required
def add_to_watchlist(request, listing_id):
    listing = get_object_or_404(Listing, pk=listing_id)
    watchlist, created = Watchlist.objects.get_or_create(user=request.user)
    if listing in watchlist.listings.all():
        watchlist.listings.remove(listing)
        messages.info(request, "Listing removed from watchlist.")
    else:
        watchlist.listings.add(listing)
        messages.success(request, "Listing added to watchlist.")
    return redirect("view_listing", listing_id=listing_id)

# View for placing a bid on a listing
@login_required
def place_bid(request, listing_id):
    listing = get_object_or_404(Listing, pk=listing_id)
    if listing.creator == request.user:
        messages.error(request, "You cannot bid on your own listing.")
        return redirect("view_listing", listing_id=listing_id)
    if not listing.active:
        messages.error(request, "This auction is closed.")
        return redirect("view_listing", listing_id=listing_id)
    if request.method == "POST":
        form = BidForm(request.POST)
        if form.is_valid():
            bid_amount = form.cleaned_data["bid_amount"]
            current_highest_bid = listing.bids.order_by("-bid_amount").first()
            if current_highest_bid is None or bid_amount > current_highest_bid.bid_amount:
                Bid.objects.create(listing=listing, user=request.user, bid_amount=bid_amount)
                messages.success(request, "Bid placed successfully!")
            else:
                messages.error(request, "Bid must be higher than the current highest bid.")
        else:
            messages.error(request, "There was a problem with your bid.")
    return redirect("view_listing", listing_id=listing_id)

# View for adding a comment to a listing
@login_required
def add_comment(request, listing_id):
    listing = get_object_or_404(Listing, pk=listing_id)
    if request.method == "POST":
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.user = request.user
            comment.listing = listing
            comment.save()
            messages.success(request, "Comment posted.")
        else:
            messages.error(request, "There was a problem posting your comment.")
    return redirect("view_listing", listing_id=listing_id)

# View for displaying the user's watchlist
@login_required
def view_watchlist(request):
    watchlist = Watchlist.objects.filter(user=request.user).first()
    listings = watchlist.listings.all() if watchlist else []
    return render(request, "auctions/watchlist.html", {"listings": listings})

# View for displaying all listing categories
def view_categories(request):
    categories = Category.objects.all()
    return render(request, "auctions/categories.html", {"categories": categories})

# View for displaying all active listings in a given category
def view_category_listings(request, category_id):
    category = get_object_or_404(Category, pk=category_id)
    listings = category.listings.filter(active=True)
    return render(request, "auctions/category.html", {
        "category": category,
        "listings": listings
    })

# View for the listing creator to close an auction
@login_required
def close_auction(request, listing_id):
    listing = get_object_or_404(Listing, pk=listing_id)
    if listing.creator != request.user:
        messages.error(request, "You are not authorized to close this auction.")
        return redirect("view_listing", listing_id=listing_id)
    if not listing.active:
        messages.error(request, "This auction is already closed.")
        return redirect("view_listing", listing_id=listing_id)

    listing.active = False
    highest_bid = listing.bids.order_by("-bid_amount").first()
    if highest_bid:
        listing.winner = highest_bid.user
    listing.save()
    messages.success(request, "The auction has been closed.")
    return redirect("view_listing", listing_id=listing_id)
