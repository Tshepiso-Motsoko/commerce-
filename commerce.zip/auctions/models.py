from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.validators import MinValueValidator
from django.utils import timezone

class User(AbstractUser):
    pass

class Category(models.Model):
    name = models.CharField(max_length=64, unique=True)

    def __str__(self):
        return self.name

class Listing(models.Model):
    title = models.CharField(max_length=128)
    description = models.TextField()
    starting_bid = models.DecimalField(max_digits=9, decimal_places=2, validators=[MinValueValidator(0)])
    image_url = models.URLField(blank=True, null=True)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True, related_name="listings")
    creator = models.ForeignKey(User, on_delete=models.CASCADE, related_name="listings_created")
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(default=timezone.now)
    winner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="won_listings")

    def current_price(self):
        highest_bid = self.bids.order_by('-bid_amount').first()
        return highest_bid.bid_amount if highest_bid else self.starting_bid

    def __str__(self):
        return f"{self.title} by {self.creator.username}"

class Bid(models.Model):
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="bids")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="bids_made")
    bid_amount = models.DecimalField(max_digits=9, decimal_places=2, validators=[MinValueValidator(0)])
    time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.bid_amount} by {self.user.username} on {self.listing.title}"

class Comment(models.Model):
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="comments")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="comments_made")
    content = models.TextField()
    time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Comment by {self.user.username} on {self.listing.title}"

class Watchlist(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="watchlist")
    listings = models.ManyToManyField(Listing, blank=True, related_name="watchlisted_by")

    def __str__(self):
        return f"{self.user.username}'s Watchlist"
